#!/usr/bin/env python3
"""
G-code Deep Hole Pecking Converter
Converts CUSTOM DEEP HOLE drilling operations into pecking cycles.
"""

import re
import sys
from pathlib import Path


def extract_z_value(line):
    """Extract Z value from a G-code line."""
    match = re.search(r'Z(-?\d+\.?\d*)', line, re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None


def extract_feed_rate(line):
    """Extract feed rate from a G-code line."""
    match = re.search(r'F(\d+\.?\d*)', line, re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None


def extract_spindle_speed(line):
    """Extract spindle speed from a G-code line."""
    match = re.search(r'S(\d+\.?\d*)', line, re.IGNORECASE)
    if match:
        return match.group(0)  # Return full "S####" string
    return None


def extract_q_value(line):
    """Extract Q (peck depth) value from CUSTOM DEEP HOLE comment."""
    # Look for Q followed by = or . and decimal number
    # Pattern captures: Q=.030, Q.03, Q0.03, Q=0.03
    match = re.search(r'Q[=\s]*(\.\d+|\d+\.?\d*)', line, re.IGNORECASE)
    if match:
        q_str = match.group(1)
        q_value = float(q_str)
        return q_value
    return None


def find_custom_deep_hole_section(lines):
    """
    Find the CUSTOM DEEP HOLE section and extract necessary parameters.
    Returns: (start_idx, end_idx, params_dict) or (None, None, None)
    """
    custom_hole_idx = None
    
    # Find the CUSTOM DEEP HOLE line
    for i, line in enumerate(lines):
        if 'CUSTOM DEEP HOLE' in line.upper():
            custom_hole_idx = i
            break
    
    if custom_hole_idx is None:
        return None, None, None
    
    # Extract Q value from the CUSTOM DEEP HOLE line
    q_value = extract_q_value(lines[custom_hole_idx])
    if q_value is None:
        print(f"Warning: Could not extract Q value from line {custom_hole_idx + 1}")
        return None, None, None
    
    # Find the drilling section
    # Strategy: Find G00 Z (clearance), then G01 Z (start drilling)
    section_start = None
    clearance_z = None
    retract_height = None
    positioning_feed = None
    
    # Find G00 Z line (should have only Z, no X or Y)
    for i in range(custom_hole_idx + 1, len(lines)):
        line = lines[i].strip()
        # Look for G00 Z move without X or Y
        if ('G00' in line.upper() or ('G0 ' in line.upper() and 'G01' not in line.upper())) and 'Z' in line.upper():
            if 'X' not in line.upper() and 'Y' not in line.upper():
                z_val = extract_z_value(line)
                if z_val is not None:
                    clearance_z = z_val
                    # Now find the first G01 Z move after this
                    for j in range(i + 1, len(lines)):
                        line_j = lines[j].strip()
                        if ('G01' in line_j.upper() or 'G1 ' in line_j.upper()) and 'Z' in line_j.upper():
                            section_start = j
                            feed = extract_feed_rate(line_j)
                            if feed is not None:
                                positioning_feed = feed
                            break
                    break
    
    if section_start is None:
        print("Warning: Could not find drilling section start")
        return None, None, None
    
    # Find the section end and extract parameters
    drilling_feed = None
    final_depth = None
    start_depth = None  # The first drilling depth (e.g., Z-0.15)
    section_end = section_start
    spindle_changes = []  # Track spindle speed changes with their line positions
    found_start_depth = False
    found_final_depth = False
    
    for i in range(section_start, min(section_start + 20, len(lines))):
        line = lines[i].strip()
        
        # Track spindle speed changes
        s_code = extract_spindle_speed(line)
        if s_code:
            spindle_changes.append((i - section_start, s_code))
        
        # Look for Z moves (can be G1, G01, or just Z on a line by itself)
        if 'Z' in line.upper():
            z_val = extract_z_value(line)
            feed = extract_feed_rate(line)
            
            if z_val is not None:
                # First drilling move - this is our start depth (retract height for pecking)
                if not found_start_depth and i == section_start:
                    start_depth = z_val
                    found_start_depth = True
                    if feed is not None:
                        positioning_feed = feed
                # If this is a downward move (more negative than current final depth or first depth)
                elif z_val < (final_depth if final_depth is not None else start_depth):
                    final_depth = z_val
                    if feed is not None:
                        drilling_feed = feed
                    # Don't update section_end yet, wait for the spindle change
                # If we hit a Z move going up (retract) after finding final depth, that's the retract line
                elif found_final_depth and z_val > final_depth:
                    # This is the retract move - save it but don't include in section to replace
                    section_end = i - 1  # End before the retract line
                    break
                # If this is after a spindle speed change and we have a final depth, this might be the retract
                elif final_depth is not None and z_val > final_depth:
                    # Found the retract after drilling
                    section_end = i - 1  # End before the retract line
                    found_final_depth = True
                    break
        
        # After finding final depth and seeing the last spindle change, mark that we're done drilling
        if final_depth is not None and not found_final_depth and s_code and 'S500' in s_code.upper():
            section_end = i  # Include the final spindle change
            found_final_depth = True
    
    # Use start_depth as retract height for pecking
    retract_height = start_depth if start_depth is not None else clearance_z
    
    # Find the final retract move (G1 Z with positive or higher Z value after drilling)
    # This is just to verify there is one, but we don't include it in the section to replace
    has_final_retract = False
    for i in range(section_end + 1, min(section_end + 10, len(lines))):
        line = lines[i].strip()
        if 'G1' in line.upper() and 'Z' in line.upper():
            z_val = extract_z_value(line)
            if z_val is not None and z_val > final_depth:
                has_final_retract = True
                break
    
    if drilling_feed is None:
        print("Warning: Could not extract drilling feed rate")
        drilling_feed = positioning_feed if positioning_feed is not None else 40  # Fallback
    
    if positioning_feed is None:
        print("Warning: Could not extract positioning feed rate, using drilling feed")
        positioning_feed = drilling_feed if drilling_feed is not None else 40
    
    params = {
        'q_value': q_value,
        'retract_height': retract_height,
        'final_depth': final_depth,
        'positioning_feed': positioning_feed,
        'drilling_feed': drilling_feed,
        'spindle_changes': spindle_changes
    }
    
    return section_start, section_end, params


def generate_pecking_cycle(params):
    """
    Generate pecking cycle G-code lines.
    Returns list of strings (G-code lines).
    """
    q = params['q_value']
    retract_z = params['retract_height']
    final_z = params['final_depth']
    pos_feed = params['positioning_feed']
    drill_feed = params['drilling_feed']
    spindle_changes = params['spindle_changes']
    
    lines = []
    current_depth = retract_z
    peck_num = 0
    spindle_idx = 0
    
    # Start at retract height
    lines.append(f"G1 Z{retract_z:.4f} F{pos_feed:.0f}")
    
    # Add first spindle speed change if it occurs at the beginning
    while spindle_idx < len(spindle_changes) and spindle_changes[spindle_idx][0] <= 1:
        lines.append(spindle_changes[spindle_idx][1])
        spindle_idx += 1
    
    # Pecking loop
    while current_depth > final_z:
        peck_num += 1
        
        # Calculate next depth
        next_depth = current_depth - q
        
        # If we would go past final depth, just go to final depth
        if next_depth < final_z:
            next_depth = final_z
        
        # Drill down
        lines.append(f"G1 Z{next_depth:.4f} F{drill_feed:.0f}")
        current_depth = next_depth
        
        # If not at final depth yet, retract
        if current_depth > final_z:
            lines.append(f"G1 Z{retract_z:.4f} F{pos_feed:.0f}")
    
    # Add remaining spindle speed changes (typically the last one before final retract)
    while spindle_idx < len(spindle_changes):
        lines.append(spindle_changes[spindle_idx][1])
        spindle_idx += 1
    
    # Final retract to safety (will be added from original code)
    
    return lines


def convert_gcode_file(input_file):
    """
    Convert G-code file with CUSTOM DEEP HOLE to pecking cycle.
    Creates new file with _pecking suffix.
    """
    input_path = Path(input_file)
    
    if not input_path.exists():
        print(f"Error: File '{input_file}' not found.")
        return False
    
    # Read input file
    with open(input_path, 'r') as f:
        lines = f.readlines()
    
    # Strip newlines but keep track of original format
    lines_stripped = [line.rstrip('\n\r') for line in lines]
    
    # Find and analyze the CUSTOM DEEP HOLE section
    start_idx, end_idx, params = find_custom_deep_hole_section(lines_stripped)
    
    if start_idx is None:
        print("Error: Could not find or parse CUSTOM DEEP HOLE section.")
        return False
    
    print("Found CUSTOM DEEP HOLE section:")
    print(f"  Peck depth (Q): {params['q_value']:.4f}")
    print(f"  Retract height: Z{params['retract_height']:.4f}")
    print(f"  Final depth: Z{params['final_depth']:.4f}")
    print(f"  Positioning feed: F{params['positioning_feed']:.0f}")
    print(f"  Drilling feed: F{params['drilling_feed']:.0f}")
    
    # Calculate number of pecks
    total_depth = abs(params['final_depth'] - params['retract_height'])
    num_pecks = int(total_depth / params['q_value'])
    if total_depth % params['q_value'] > 0.0001:  # Account for floating point
        num_pecks += 1
    print(f"  Number of pecks: {num_pecks}")
    
    # Generate pecking cycle
    pecking_lines = generate_pecking_cycle(params)
    
    # Find the final retract line after the drilling section
    final_retract_line = None
    final_retract_idx = end_idx
    for i in range(end_idx + 1, min(end_idx + 10, len(lines_stripped))):
        line = lines_stripped[i].strip()
        # Look for any Z move going upward (can be G1, G01, or just Z)
        if 'Z' in line.upper():
            z_val = extract_z_value(line)
            if z_val is not None and z_val > params['final_depth']:
                final_retract_line = lines_stripped[i]
                final_retract_idx = i
                break
    
    # If we didn't find a retract line, add one
    if final_retract_line is None:
        # Create a retract line to safety height
        safety_height = params['retract_height'] + abs(params['retract_height']) + 0.5
        final_retract_line = f"G1 Z{safety_height:.4f} F{params['positioning_feed']:.0f}"
        final_retract_idx = end_idx
    
    # Construct new file content
    new_lines = []
    new_lines.extend(lines_stripped[:start_idx])  # Everything before drilling
    new_lines.extend(pecking_lines)  # New pecking cycle
    new_lines.append(final_retract_line)  # Final retract
    new_lines.extend(lines_stripped[final_retract_idx + 1:])  # Everything after drilling
    
    # Create output filename
    output_path = input_path.parent / f"{input_path.stem}_pecking{input_path.suffix}"
    
    # Write output file
    with open(output_path, 'w') as f:
        f.write('\n'.join(new_lines))
        if lines[-1].endswith('\n'):
            f.write('\n')
    
    print(f"\n✓ Successfully created: {output_path}")
    print(f"  Original lines {start_idx + 1}-{final_retract_idx + 1} replaced with {len(pecking_lines) + (1 if final_retract_line else 0)} lines")
    
    return True


def main():
    """Main function."""
    if len(sys.argv) < 2:
        print("G-code Deep Hole Pecking Converter")
        print("=" * 50)
        print("\nConverts CUSTOM DEEP HOLE drilling operations into pecking cycles.")
        print("\nUsage:")
        print("  python gcode_peck_converter.py <gcode_file>")
        print("\nExample:")
        print("  python gcode_peck_converter.py O9999.NC")
        print("\nOutput:")
        print("  Creates new file: <original_name>_pecking.NC")
        sys.exit(1)
    
    input_file = sys.argv[1]
    convert_gcode_file(input_file)


if __name__ == "__main__":
    main()
