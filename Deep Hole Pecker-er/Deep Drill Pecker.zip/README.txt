# G-code Deep Hole Pecking Converter

Converts deep hole drilling operations into pecking cycles with full retract.

================================================================================
SETUP IN FUSION 360
================================================================================

1. CREATE THE DRILLING OPERATION:
   - Operation Name: "CUSTOM DEEP HOLE - Q=.XXXX"
     Example: "CUSTOM DEEP HOLE - Q=.030" for 0.030" peck depth
   
2. CONFIGURE THE CYCLE TAB:
   - Operation Type: "Guided Deep Drilling - Gun Drilling"
   - Enter your desired start depth (retract height)
   - Enter positioning feed rate (for retracts between pecks)
   - Enter positioning spindle speed (for positioning moves/retracts)

3. POST PROCESS AS NORMAL
   - Generate your NC file from Fusion

4. RUN THIS CONVERTER
   - Drag NC file onto convert_to_pecking.bat
   - Output file created with "_pecking" suffix

================================================================================
INSTALLATION (WINDOWS)
================================================================================

1. Install Python 3.8 or newer from: https://www.python.org/downloads/
   
   IMPORTANT: On the FIRST installation screen:
   - Look for checkbox that says "Add python.exe to PATH" or "Add Python to PATH"
   - It's usually at the BOTTOM of the first screen
   - CHECK THIS BOX before clicking "Install Now"
   
   If you don't see this option:
   - You may have clicked "Customize Installation" - go back
   - Or use "Install Now" which should add it by default
   - Or manually add Python to PATH after installation (see troubleshooting)

2. Extract ALL files to the same folder:
   - gcode_peck_converter.py (the converter script)
   - convert_to_pecking.bat (drag-and-drop launcher)
   - README.txt (this file)
   
3. Keep your NC files in the same folder or drag them onto the batch file

NOTE: The batch file will try 'py' command first (works without PATH),
      then 'python' command as backup

================================================================================
HOW TO USE
================================================================================

DRAG AND DROP (EASIEST):
  1. Drag your NC file onto "convert_to_pecking.bat"
  2. Output file appears as YOUR_FILE_pecking.NC

COMMAND LINE (ALTERNATIVE):
  Open Command Prompt in the folder and run:
  py gcode_peck_converter.py YOUR_FILE.NC
  (or use 'python' instead of 'py' if Python is in PATH)

OUTPUT:
  Creates YOUR_FILE_pecking.NC in same folder

================================================================================
WHAT IT DOES
================================================================================

Finds "CUSTOM DEEP HOLE - Q=.XXXX" operations and converts them to pecking:
  - Drills down by Q amount (peck depth) at drilling feed rate
  - Fully retracts to start depth at positioning feed rate
  - Repeats until final depth reached
  - Preserves spindle speeds and final retract moves

================================================================================
TROUBLESHOOTING
================================================================================

ERROR: "python is not recognized" or "can't open file"
  CAUSE: Python not installed or not accessible
  
  TRY FIRST: The batch file should automatically try 'py' command
             Just drag your NC file onto convert_to_pecking.bat
  
  IF THAT FAILS:
  Option 1 - Reinstall Python:
    - Download from python.org
    - On FIRST screen, check "Add python.exe to PATH" at the bottom
    - Click "Install Now"
  
  Option 2 - Use Python Launcher (if already installed):
    - Open Command Prompt in your folder
    - Type: py gcode_peck_converter.py YOUR_FILE.NC
  
  Option 3 - Manually add Python to PATH:
    - Search Windows for "Environment Variables"
    - Click "Environment Variables" button
    - Under "System variables", find "Path", click "Edit"
    - Click "New" and add: C:\Users\YourName\AppData\Local\Programs\Python\Python3XX
    - Also add: C:\Users\YourName\AppData\Local\Programs\Python\Python3XX\Scripts
    - Click OK on all dialogs, restart Command Prompt

ERROR: "No CUSTOM DEEP HOLE section found"
  CAUSE: Operation name doesn't match required format
  FIX: In Fusion 360, name operation exactly:
       "CUSTOM DEEP HOLE - Q=.030" (or your desired peck depth)
       Must include "CUSTOM DEEP HOLE" and "Q=" with a number

ERROR: Wrong peck depth generated
  CAUSE: Q value not extracted correctly from operation name
  FIX: Use format Q=.030 or Q=0.030 or Q.03
       Check operation name spelling in Fusion

ERROR: Wrong retract height
  CAUSE: Script misidentified the drilling section
  FIX: Ensure your drilling operation has:
       - G00 Z move to clearance height
       - G01 Z move to start depth with feed rate
       - Final Z move to deepest depth
       - Retract move back up

All files must be in same folder:
  - Don't move files after extracting from zip
  - Keep gcode_peck_converter.py and convert_to_pecking.bat together
  - NC files can be anywhere, just drag onto the batch file
