# G-code Deep Hole Pecking Converter

Converts deep hole drilling operations into pecking cycles with full retract.

================================================================================
SETUP IN FUSION 360
================================================================================

1. CREATE THE DRILLING OPERATION:
   - Operation Name: "CUSTOM DEEP HOLE - Q=.XXXX"
     Example: "CUSTOM DEEP HOLE - Q=.030" for 0.030" peck depth
   
2. CONFIGURE THE CYCLE TAB:
   - Operation Type: "Guided Deep Drilling - Gun Drilling"
   - Enter your desired start depth (retract height)
   - Enter positioning feed rate (for retracts between pecks)
   - Enter positioning spindle speed (for positioning moves/retracts)

3. POST PROCESS AS NORMAL
   - Generate your NC file from Fusion

4. RUN THIS CONVERTER
   - Drag NC file onto convert_to_pecking.bat
   - Output file created with "_pecking" suffix

================================================================================
INSTALLATION (WINDOWS)
================================================================================

1. Install Python 3 from: https://www.python.org/downloads/
   IMPORTANT: Check "Add Python to PATH" during installation

2. Keep these files together:
   - gcode_peck_converter.py
   - convert_to_pecking.bat
   - README.txt

================================================================================
HOW TO USE
================================================================================

DRAG AND DROP (EASIEST):
  Drag your NC file onto "convert_to_pecking.bat"

COMMAND LINE:
  python gcode_peck_converter.py YOUR_FILE.NC

OUTPUT:
  Creates YOUR_FILE_pecking.NC in same folder

================================================================================
WHAT IT DOES
================================================================================

Finds "CUSTOM DEEP HOLE - Q=.XXXX" operations and converts them to pecking:
  - Drills down by Q amount (peck depth) at drilling feed rate
  - Fully retracts to start depth at positioning feed rate
  - Repeats until final depth reached
  - Preserves spindle speeds and final retract moves

================================================================================
TROUBLESHOOTING
================================================================================

"python is not recognized"
  → Python not installed or not in PATH
  → Reinstall Python, check "Add Python to PATH"

"No CUSTOM DEEP HOLE section found"
  → Operation name must include "CUSTOM DEEP HOLE - Q=.XXXX"
  → Check exact spelling and format in Fusion

Wrong peck depth
  → Q value format: Q=.030 or Q.03 or Q=0.03
  → Check operation name in Fusion
